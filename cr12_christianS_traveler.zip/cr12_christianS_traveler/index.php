<?php get_header() ?>
	   <h2 class="text-center">Mount Everest Travel Agency</h2>
	   <div class="container maincont">
	   	<div class="row">
	 		<div class="col-2 contleft" style= 'background-image: url("https://images.unsplash.com/photo-1517384084767-6bc118943770?ixlib=rb-1.2.1&ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&auto=format&fit=crop&w=934&q=80")'>
	 				<div class="sidebar">Add Your Widget Here
	<?php
      if(is_active_sidebar('sidebar')):
     dynamic_sidebar('sidebar');
     endif;  
	?>
	</div>
			</div>
		<div class="col-md-7 col-sm-12 contmiddle">
			<div class="container contcontainer">
				<div class="row">

	       <?php if(have_posts()) : ?> <!--  If there are posts available  -->

	       <?php while(have_posts()) : the_post(); ?> <!-- if there are posts, iterate the posts in the loop
	-->

			<div class="col-lg-6 col-sm-12">
				<div class="card">
				  <div class="card-body">
				    <h5 class="card-title"><?php the_title(); ?></h5>
				    <h6 class="card-subtitle mb-2 text-muted"> <?php the_author(); ?><?php the_time(' g:i a j F Y'); ?></h6>
				    <p class="card-text"> <?php the_content(); ?></p>
				    <a href="<?php the_permalink(); ?>" class="card-link">Go there</a>
				  </div>
				  
				  <?php comments_template(); ?>

				</div>
				</div>
		       <p></p><!--retrieves date blog entry was created-->

		       <!--retrieves author of blog entry-->
		       
		      <!--retrieves content-->

		       <?php endwhile; ?><!--end the while loop-->

		       <?php else :?> <!-- if no posts are found then: -->

		       <p>No posts found</p>  <!-- no posts found displayed -->
		       <?php endif; ?> <!-- end if -->
		   	  
	   		 </div>
	   		</div>
	   	   </div>
	   	  <div class="col-2 contright" style= 'background-image: url("https://images.unsplash.com/photo-1517384084767-6bc118943770?ixlib=rb-1.2.1&ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&auto=format&fit=crop&w=934&q=80")'></div>
		</div>
	</div>
	


<?php get_footer(); ?>